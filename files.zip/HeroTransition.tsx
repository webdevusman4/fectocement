"use client";
import { useRef } from "react";
import Image from "next/image";
import { motion, useMotionValueEvent, useScroll, useTransform } from "framer-motion";

const IMG = "/images/sangjani-plant.jpg"; // placeholder
const VID = "/media/sangjani-plant.mp4"; // placeholder

export default function HeroTransition() {
  const ref = useRef<HTMLElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });

  // q: 0 = full-bleed hero, 1 = right-half video card. Morph finishes at 60% of the pin.
  const q = useTransform(scrollYProgress, [0, 0.6], [0, 1]);

  // Percentages are relative to the sticky stage, so no scrollbar-width jitter.
  const width = useTransform(q, [0, 1], ["100%", "50%"]);
  const height = useTransform(q, [0, 1], ["100%", "74%"]);
  const right = useTransform(q, [0, 1], ["0%", "5%"]);
  const top = useTransform(q, [0, 1], ["0%", "13%"]);
  const radius = useTransform(q, [0, 1], [0, 32]);

  const videoOpacity = useTransform(q, [0.7, 1], [0, 1]);
  const heroTextOpacity = useTransform(q, [0, 0.35], [1, 0]);
  const introOpacity = useTransform(q, [0.55, 1], [0, 1]);
  const introX = useTransform(q, [0.55, 1], [-48, 0]);

  useMotionValueEvent(q, "change", (v) => {
    const el = video.current;
    if (!el) return;
    if (v > 0.6 && el.paused) el.play().catch(() => {});
    if (v < 0.4 && !el.paused) el.pause();
  });

  return (
    <section ref={ref} className="relative h-[220vh]">
      <div className="sticky top-0 h-svh overflow-hidden">
        {/* The media frame: image first, crossfades to video */}
        <motion.div
          style={{ width, height, right, top, borderRadius: radius }}
          className="absolute z-10 overflow-hidden shadow-2xl shadow-slate-900/30"
        >
          <Image src={IMG} alt="Fecto Cement plant at Sangjani" fill priority sizes="100vw" className="object-cover" />
          <motion.video
            ref={video}
            style={{ opacity: videoOpacity }}
            className="absolute inset-0 h-full w-full object-cover"
            src={VID}
            poster={IMG}
            muted
            loop
            playsInline
            preload="metadata"
          />
          <motion.div style={{ opacity: heroTextOpacity }} className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-slate-950/10 to-transparent" />
        </motion.div>

        {/* Full-bleed headline, fades as the frame shrinks */}
        <motion.div style={{ opacity: heroTextOpacity }} className="absolute bottom-[14vh] left-[6vw] z-20 text-white">
          <h1 className="font-display text-6xl font-bold leading-[0.92] tracking-tight md:text-8xl">A Name<br />of Faith.</h1>
        </motion.div>

        {/* Intro text revealed on the left */}
        <div className="absolute left-[6vw] top-1/2 z-20 w-[38%] -translate-y-1/2">
          <motion.div style={{ opacity: introOpacity, x: introX }}>
            <h2 className="font-display text-4xl font-bold leading-tight tracking-tight text-slate-900 xl:text-5xl">Made at Sangjani since 1981.</h2>
            <p className="mt-5 max-w-md text-slate-700">High-performance cement for the dams, motorways and towers Pakistan is built on.</p>
            <a href="#products" className="mt-7 inline-block rounded-full bg-[#F4D5AB] px-6 py-3 font-medium text-[#000080]">Explore products</a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
