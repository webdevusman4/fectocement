"use client";
import { useEffect, useRef } from "react";
import { animate, motion, useInView, useMotionValue, useTransform } from "framer-motion";

function Counter({ to, decimals = 0, group = true }: { to: number; decimals?: number; group?: boolean }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-15% 0px" });
  const mv = useMotionValue(0);
  const text = useTransform(mv, (v) =>
    v.toLocaleString("en", { minimumFractionDigits: decimals, maximumFractionDigits: decimals, useGrouping: group })
  );
  useEffect(() => {
    if (!inView) return;
    const c = animate(mv, to, { duration: 1.4, ease: "easeOut" });
    return () => c.stop();
  }, [inView, to, mv]);
  return <motion.span ref={ref}>{text}</motion.span>;
}

// Sample figures from a reference page. Confirm with Fecto before launch.
const STATS = [
  { to: 0.8, decimals: 1, unit: "million tons a year", label: "Installed capacity at Sangjani", cls: "col-span-2" },
  { to: 3000, unit: "tons a day", label: "Dry-process clinker line", cls: "" },
  { to: 1981, group: false, unit: "", label: "Fecto Cement Limited is established", cls: "" },
];

export default function StatsBento() {
  return (
    <section className="relative z-10 mx-auto -mt-20 max-w-7xl p-8">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {STATS.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-10%" }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
            className={`glass-arctic rounded-3xl p-6 ${s.cls}`}
          >
            <p className="flex items-baseline gap-3">
              <span className="font-display text-5xl font-bold tracking-tight text-[#000080]">
                <Counter to={s.to} decimals={s.decimals} group={s.group} />
              </span>
              {s.unit && <span className="text-lg text-slate-700">{s.unit}</span>}
            </p>
            <p className="mt-2 text-sm text-slate-600">{s.label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
