import PlantCanvas from "@/components/PlantCanvas";
import HeroTransition from "@/components/HeroTransition";
import StatsBento from "@/components/StatsBento";

export default function Home() {
  return (
    // relative + isolate keeps the -z-20 canvas inside this stacking context.
    // No overflow-hidden here or on any ancestor, or sticky breaks.
    <main className="relative isolate">
      <PlantCanvas />
      <HeroTransition />
      <StatsBento />
      {/* Next sections: keep backgrounds transparent so the frosted plant shows through.
          Dark chapters (energy, investors, timeline) use their own opaque bg and simply cover the canvas. */}
    </main>
  );
}
